
AFB - v1 first set
==============================

This dataset was exported via roboflow.ai on December 26, 2021 at 9:11 PM GMT

It includes 880 images.
A are annotated in Tensorflow TFRecord (raccoon) format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 461x364 (Stretch)

No image augmentation techniques were applied.


